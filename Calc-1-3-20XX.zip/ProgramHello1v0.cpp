#include <iostream>
using namespace std;

int main()
{
    double num1, num2;
    char op;

    cout << "Enter two numbers: ";
    cin >> num1 >> num2;

    cout << "Enter an operator (+, -, *, /): ";
    cin >> op;

    switch(op)
    {
        case '+':
            cout << num1+num2;
            break;

        case '-':
            cout << num1-num2;
            break;

        case '*':
            cout << num1*num2;
            break;

        case '/':
            if (num2 == 0)
            {
                cout << "Error! Division by zero is not allowed.";
            }
            else
            {
                cout << num1/num2;
            }
            break;

        default:
            cout << "Error! operator is not correct";
            break;
    }

    return 0;
}
